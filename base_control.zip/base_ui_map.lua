-- Part of the base-control program (started by inventory.lua).
-- All base_*.lua files share one namespace and are loaded in a fixed order.

-- page drawing: MAP
local BLIT = {}
local function blitc(c)
  local v = BLIT[c]
  if not v then
    v = string.format("%x", math.floor(math.log(c) / math.log(2) + 0.5))
    BLIT[c] = v
  end
  return v
end

-- world -> screen position (follows the map rotation)
local function toScreen(g, V, x, z)
  local sx, sy = MAP.toCell(x, z)
  local i = math.floor(sx + g.mw / 2 + 0.5)
  local j = math.floor(sy + g.mh / 2 + 0.5)
  if i >= 0 and i < g.mw and j >= 0 and j < g.mh then return g.mx0 + i, g.my0 + j end
end

function mapWorldAt(tx, ty)
  local g = state.mapGeom
  if not g then return nil end
  return MAP.toWorld(tx - g.mx0 - g.mw / 2, ty - g.my0 - g.mh / 2)
end

function drawMapPage(G)
  local y0, bottom = G.y0, G.y1
  local V = MAP.view()
  local sideW = 38
  local lx = 2
  local mapW = W - 3 - sideW
  local rx = lx + mapW + 1
  local rw = W - rx
  local rix, riw = rx + 2, rw - 4

  ------------------------------------------------ the map
  card(lx, y0, mapW, bottom - y0 + 1, "MAP")
  local cTop, cRight, cBottom, cLeft, upName = MAP.compass()
  local scale = "UP: " .. upName .. "   " ..
                (V.zoom == 1 and "1 cell = 1 block" or ("1 cell = " .. V.zoom .. " blocks"))
  text(lx + mapW - #scale - 3, y0 + 1, scale, C.dim, C.panel)
  local g = { mx0 = lx + 1, my0 = y0 + 2, mw = mapW - 2, mh = bottom - y0 - 2 }
  state.mapGeom = g
  local bgEmpty = blitc(C.bg)
  local fgGrid = blitc(C.head)
  -- the map image is rebuilt only when the map data or the view changed;
  -- otherwise the rows from last time are put on the screen again
  local key = table.concat({ MAP.version, V.cx, V.cz, V.zoom, V.rot or 0, g.mx0, g.my0, g.mw, g.mh }, ",")
  local cache = state.mapImage
  if not cache or cache.key ~= key then
    cache = { key = key, rows = {} }
    local B = MAP.basis()
    local zx, zy = V.zoom, V.zoom * 1.5
    local cxs, czs = V.cx, V.cz
    local floor, get, names, colorOf = math.floor, MAP.get, MAP.names, MAP.colorOf
    for j = 0, g.mh - 1 do
      local tx, fg, bg = {}, {}, {}
      local b2 = (j - g.mh / 2) * zy
      for i = 0, g.mw - 1 do
        local a2 = (i - g.mw / 2) * zx
        local wx = cxs + floor(a2 * B.rx + b2 * B.dx)
        local wz = czs + floor(a2 * B.rz + b2 * B.dz)
        local c = get(wx, wz)
        if c then
          tx[i + 1] = " "
          fg[i + 1] = fgGrid
          bg[i + 1] = blitc(colorOf(names[c[2]] or ""))
        else
          -- unscanned: dark, with faint dots on chunk borders (zoomed in)
          local edge = V.zoom == 1 and (wx % 16 == 0 or wz % 16 == 0)
          tx[i + 1] = edge and "." or " "
          fg[i + 1] = fgGrid
          bg[i + 1] = bgEmpty
        end
      end
      cache.rows[j] = { table.concat(tx), table.concat(fg), table.concat(bg) }
    end
    state.mapImage = cache
  end
  for j = 0, g.mh - 1 do
    local r = cache.rows[j]
    win.setCursorPos(g.mx0, g.my0 + j)
    win.blit(r[1], r[2], r[3])
  end
  addHit(g.mx0, g.my0, g.mw, g.mh, "mapcell")

  -- compass letters on the four edges
  local midX, midY = g.mx0 + math.floor(g.mw / 2), g.my0 + math.floor(g.mh / 2)
  text(midX, g.my0, cTop, C.ink, C.accent)
  text(midX, g.my0 + g.mh - 1, cBottom, C.text, C.empty)
  text(g.mx0, midY, cLeft, C.text, C.empty)
  text(g.mx0 + g.mw - 1, midY, cRight, C.text, C.empty)

  -- overlays: ores, base, players, drones, turtles, selection
  local h = CONFIG.drone.home
  if h then
    local sx, sy = toScreen(g, V, h.x, h.z)
    if sx then text(sx, sy, "B", C.ink, C.warn) end
  end
  for _, e in ipairs(state.players or {}) do
    if e.p and e.p.x then
      local sx, sy = toScreen(g, V, e.p.x, e.p.z)
      if sx then text(sx, sy, "@", C.ink, e.name == state.owner and C.accent or C.label) end
    end
  end
  for _, k in ipairs(droneOrder) do
    local dr = drones[k]
    if dr.pos then
      local sx, sy = toScreen(g, V, dr.pos.x, dr.pos.z)
      if sx then text(sx, sy, "D", C.ink, colors.pink) end
    end
  end
  for _, t in pairs(state.turtles) do
    if t.pos and t.pos.x then
      local sx, sy = toScreen(g, V, t.pos.x, t.pos.z)
      if sx then
        if t.stuck then text(sx, sy, "!", C.ink, C.bad)
        else text(sx, sy, "T", C.ink, state.tSel == t.id and C.accent or C.good) end
      end
    end
  end
  local sel = state.mapSel
  if sel then
    local sx, sy = toScreen(g, V, sel.x, sel.z)
    if sx then text(sx, sy, "+", C.text, C.bad) end
  end

  ------------------------------------------------ right column: view controls
  card(rx, y0, rw, 15, "VIEW")
  actButton(rx + rw - 15, y0 + 1, 13, 1, "CLEAR MAP", { kind = "mapclear", name = "map", count = 0 })
  kv(rix, y0 + 3, riw, "Centre", V.cx .. ", " .. V.cz)
  kv(rix, y0 + 4, riw, "Mapped chunks", tostring(#MAP.order))
  kv(rix, y0 + 5, riw, "Scans", tostring(MAP.scans))
  local bw = math.floor((riw - 3) / 4)
  local b1 = y0 + 7
  drawButton(rix,                b1, bw, 1, "\27",  C.empty, C.text, "mpan", { -1, 0 })
  drawButton(rix + bw + 1,       b1, bw, 1, "\24",  C.empty, C.text, "mpan", { 0, -1 })
  drawButton(rix + 2 * (bw + 1), b1, bw, 1, "\25",  C.empty, C.text, "mpan", { 0, 1 })
  drawButton(rix + 3 * (bw + 1), b1, bw, 1, "\26",  C.empty, C.text, "mpan", { 1, 0 })
  local b2 = y0 + 9
  drawButton(rix,                b2, bw, 1, "ZOOM -", C.empty, C.text, "mzoom", 1)
  drawButton(rix + bw + 1,       b2, bw, 1, "ZOOM +", C.empty, C.text, "mzoom", -1)
  drawButton(rix + 2 * (bw + 1), b2, bw * 2 + 1, 1, "ROTATE", C.empty, C.text, "mrot")
  local b3 = y0 + 11
  text(rix, b3, "CENTRE ON", C.dim, C.panel)
  local cw = math.floor((riw - 2) / 3)
  drawButton(rix,                b3 + 1, cw, 1, "BASE",   C.empty, C.text, "mcenter", "base")
  drawButton(rix + cw + 1,       b3 + 1, cw, 1, "TURTLE", C.empty, C.text, "mcenter", "turtle")
  drawButton(rix + 2 * (cw + 1), b3 + 1, cw, 1, "ME",     C.empty, C.text, "mcenter", "me")

  ------------------------------------------------ selected block
  local sy0 = y0 + 16
  card(rx, sy0, rw, 7, "SELECTED")
  if sel then
    local c = MAP.get(sel.x, sel.z)
    kv(rix, sy0 + 3, riw, "Column", sel.x .. ", " .. sel.z)
    if c then
      kv(rix, sy0 + 4, riw, "Top block", trunc(prettify(MAP.names[c[2]] or "?"), riw - 12))
      kv(rix, sy0 + 5, riw, "Height", "Y " .. c[1])
    else
      text(rix, sy0 + 4, "Not scanned yet", C.dim, C.panel)
    end
  else
    text(rix, sy0 + 3, "Tap the map to inspect a spot", C.dim, C.panel)
  end

  ------------------------------------------------ turtle actions
  local ty0 = sy0 + 8
  card(rx, ty0, rw, 10, "TURTLE")
  local t = state.tSel and state.turtles[state.tSel]
  if not t then
    text(rix, ty0 + 3, trunc("Select a turtle on the TURTLES tab", riw), C.dim, C.panel)
    if next(state.turtles) then
      actButton(rix, ty0 + 8, riw, 1, "SURVEY: ALL TURTLES (" .. #TT.available() .. ")",
                { kind = "surveyall", name = "all", count = 0 }, true)
    end
  else
    kv(rix, ty0 + 3, riw, trunc(t.label, riw - 12), TT.online(t) and "online" or "OFFLINE",
       TT.online(t) and C.good or C.bad)
    text(rix, ty0 + 4, trunc(tostring(t.task or "idle"), riw), C.dim, C.panel)
    local tw = math.floor((riw - 2) / 3)
    drawButton(rix, ty0 + 5, tw, 2, "SCAN HERE", C.empty, C.text, "tcmd",
               { t.id, "scan", { CONFIG.map.scanRadius } })
    drawButton(rix + tw + 1, ty0 + 5, tw, 2, "STOP", C.bad, C.ink, "tcmd", { t.id, "stop", {} })
    drawButton(rix + 2 * (tw + 1), ty0 + 5, riw - 2 * (tw + 1), 2, "STOP ALL", C.bad, C.ink, "tstopall")
    local hw = math.floor((riw - 1) / 2)
    local nfree = #TT.available()
    actButton(rix, ty0 + 8, hw, 1, "SURVEY: ALL (" .. nfree .. ")",
              { kind = "surveyall", name = "all", count = 0 }, true)
    actButton(rix + hw + 1, ty0 + 8, riw - hw - 1, 1, "SURVEY: THIS ONE",
              { kind = "survey", name = tostring(t.id), count = 0 }, true)
  end

  ------------------------------------------------ what the colours mean
  local ly = ty0 + 11
  local lh = bottom - ly + 1
  if lh >= 5 then
    card(rx, ly, rw, lh, "LEGEND")
    local items = {
      { colors.green, "Grass, plants" }, { colors.lime, "Trees, leaves" },
      { colors.blue, "Water" }, { colors.yellow, "Sand, gravel" },
      { colors.orange, "Dirt, wood, clay" }, { colors.white, "Snow, ice" },
      { colors.brown, "Stone, buildings" }, { colors.red, "Lava, nether" },
      { colors.cyan, "Warped, prismarine" }, { colors.purple, "Obsidian, amethyst" },
    }
    for i = 1, math.min(#items, lh - 4) do
      local it = items[i]
      text(rix, ly + 2 + i, "  ", C.text, it[1])
      text(rix + 3, ly + 2 + i, it[2], C.text, C.panel)
    end
  end
end
